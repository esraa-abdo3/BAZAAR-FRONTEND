"use client";

import { useState, useEffect } from "react";
// axios import removed; using brandService with auth interceptor
import BrandSidebar from "@/app/components/Dashboard/BrandownerDashboard/BrandSidebar";
import BrandHeader from "@/app/components/Dashboard/BrandownerDashboard/BrandHeader";
import BrandOverview from "@/app/components/Dashboard/BrandownerDashboard/BrandOverview";
import BrandOrders from "@/app/components/Dashboard/BrandownerDashboard/BrandOrders";
import BrandOrderDetail from "@/app/components/Dashboard/BrandownerDashboard/BrandOrderDetail";
import BrandProducts from "@/app/components/Dashboard/BrandownerDashboard/BrandProducts";
import BrandAddProduct from "@/app/components/Dashboard/BrandownerDashboard/BrandAddProduct";
import { getBrandProfile } from "@/app/services/brandService";
import BrandSettings from "@/app/components/Dashboard/BrandownerDashboard/BrandSettings";
import BrandReviews from "@/app/components/Dashboard/BrandownerDashboard/BrandReviews";

export default function BrandOwnerDashboard() {
  const [activePage, setActivePage] = useState("overview");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [editProduct, setEditProduct] = useState(null); // null = add, object = edit
  const [brandInfo, setBrandInfo] = useState({ id: "", name: "", tagline: "" });

  useEffect(() => {
    async function loadBrand() {
      try {
        const res = await getBrandProfile();
        const data = res?.data ?? res ?? {};
        setBrandInfo({
          id: data._id ?? data.id ?? "",
          name: data.brandName ?? data.name ?? "",
          tagline: data.category ?? "Global Marketplace",
        });
      } catch {
        // keep defaults if fetch fails
      }
    }
    loadBrand();
  }, []);

  function renderPage() {
    if (activePage === "order-detail")
      return (
        <BrandOrderDetail
          order={selectedOrder}
          onBack={() => setActivePage("orders")}
        />
      );
    if (activePage === "add-product")
      return (
        <BrandAddProduct
          product={editProduct}
          onBack={() => setActivePage("products")}
          onSuccess={() => setActivePage("products")}
        />
      );

    switch (activePage) {
      case "overview":
        return (
          <BrandOverview
            onViewOrders={() => setActivePage("orders")}
            onViewProducts={() => setActivePage("products")}
          />
        );
      case "orders":
        return (
          <BrandOrders
            onViewDetail={(order) => {
              setSelectedOrder(order);
              setActivePage("order-detail");
            }}
          />
        );
      case "products":
        return (
          <BrandProducts
            onAddNew={() => {
              setEditProduct(null);
              setActivePage("add-product");
            }}
            onEdit={(product) => {
              setEditProduct(product);
              setActivePage("add-product");
            }}
          />
        );
      case "settings":
        return <BrandSettings />;
      case "reviews":
        return <BrandReviews brandId={brandInfo.id} />;
      default:
        return <BrandOverview />;
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50 lg:ml-[220px]">
      <BrandSidebar
        activePage={activePage}
        setActivePage={setActivePage}
        brandName={brandInfo.name}
        brandTagline={brandInfo.tagline}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <BrandHeader />
        <main className="flex-1 overflow-auto p-4 sm:p-6 lg:p-8">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}