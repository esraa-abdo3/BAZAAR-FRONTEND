
import Navbar from "./components/Navbar/Navbar";
import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
     
    >
   
      <body className="min-h-full flex flex-col">
         <Navbar/>
        
        {children}
          



      </body>
    </html>
  );
}
