"use client";

import { useRef, useState } from "react";
import axios from "axios";

export default function Verifyotp() {

  const [otp, setOtp] = useState([
    "", "", "", "", "", ""
  ]);

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

    const inputsRef = useRef([]);
const email = localStorage.getItem("email")

  // handle change
  const handleChange = async (value, index) => {

    // numbers only
    if (value && !/^\d+$/.test(value)) {
      setError("OTP must contain numbers only");
      return;
    }

    setError("");

    const newOtp = [...otp];

    // take only one number
    newOtp[index] = value.slice(-1);

    setOtp(newOtp);

    // move to next input
    if (value && index < 5) {
      inputsRef.current[index + 1].focus();
    }

    // auto submit
    const finalOtp = newOtp.join("");

    if (finalOtp.length === 6 &&
      !newOtp.includes("")) {

      try {

        setLoading(true);

        const response = await axios.post(
          "https://iti-graduration-projrct.vercel.app/api/v1/auth/Emailverification",
          {
              otp: finalOtp,
              email
          }
        );

        console.log(response.data);


      } catch (err) {

        setError(
          err.response?.data?.msg ||
          "Invalid OTP"
        );

      } finally {
        setLoading(false);
      }
    }
  };

  // backspace focus
  const handleKeyDown = (e, index) => {

    if (
      e.key === "Backspace" &&
      !otp[index] &&
      index > 0
    ) {
      inputsRef.current[index - 1].focus();
    }
  };

  return (
    <section className="w-full h-[600px] flex items-center justify-center p-6 ">

      <div className="bg-white border border-stone-200 rounded-2xl p-10 w-full max-w-md shadow-lg">

        <div className="text-center mb-8">

          <h2 className="text-2xl font-bold mb-2">
            Verify OTP
          </h2>

          <p className="text-sm text-stone-400">
           please  Enter the 6-digit code
          </p>

        </div>

       
        <div className="flex justify-center gap-3">

          {otp.map((digit, index) => (

            <input
              key={index}
              ref={(el) =>
                (inputsRef.current[index] = el)
              }
              type="text"
              value={digit}
              maxLength={1}
              autoFocus={index === 0}
              onChange={(e) =>
                handleChange(
                  e.target.value,
                  index
                )
              }
              onKeyDown={(e) =>
                handleKeyDown(e, index)
              }
              className="w-12 h-12 border border-stone-300 rounded-lg text-center text-lg font-medium focus:outline-none focus:border-black"
            />
          ))}

        </div>

        {/* Error */}
        {error && (
          <p className="text-red-500 text-sm text-center mt-4">
            {error}
          </p>
        )}

        {/* Loading */}
        {loading && (
          <div className="flex justify-center mt-5">
            <div className="w-5 h-5 border-2 border-gray-300 border-t-black rounded-full animate-spin"></div>
          </div>
        )}

      </div>
    </section>
  );
}